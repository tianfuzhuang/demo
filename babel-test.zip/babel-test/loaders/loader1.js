

const { getOptions } = require('loader-utils')
const babel = require('@babel/core')

function loader(source) {
  console.log('loader1~~');
  const cb = this.async()
  const op = getOptions(this)
  babel.transform(source, {
    ...op,
    sourceMap: true
  }, function (err, result) {
    cb(err, result.code, result.map)
  })
}

loader.pitch = function(source) {
  console.log('pitch1');
}

module.exports = loader
