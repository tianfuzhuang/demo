
function loader(source) {
  console.log('loader2~~');
  return source
}

loader.pitch = function(source) {
  console.log('pitch2');
  return 'xxx'
}

module.exports = loader
