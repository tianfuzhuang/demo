

class Person{
  constructor(props){
    this.name = props
  }
  getName () {
    console.log(this.name)
  }
}

const p = new Person('cheng')

p.getName()
