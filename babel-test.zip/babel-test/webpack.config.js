
const path = require('path')
const { resolve } = path

module.exports = {
  entry: './src/index.js',
  output: {
    path: resolve(__dirname, 'dist'),
    filename: 'build.js'
  },
  mode: 'development',
  resolveLoader: {
    modules: ['node_modules', resolve(__dirname, 'loaders')]
  },
  module: {
    rules: [
      {
        test: /\.js/,
        use: [
          {
            loader: 'loader1',
            options: {
              presets: ['@babel/preset-env']
            }
          }
        ]
      }
    ]
  }
}
